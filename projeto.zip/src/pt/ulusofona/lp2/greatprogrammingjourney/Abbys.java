package pt.ulusofona.lp2.greatprogrammingjourney;

public class Abbys  {
    int id;
    String titulo;
    String efeito;
    String descricao;
    int estado;
}
